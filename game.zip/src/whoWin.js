import React, { Component } from 'react';
import './App.css';


export class WhoWin extends Component {
    constructor(props) {
        super(props);
    };

    checkWinner = (winCombination,elems) => {
        console.log(elems);
    }

}


